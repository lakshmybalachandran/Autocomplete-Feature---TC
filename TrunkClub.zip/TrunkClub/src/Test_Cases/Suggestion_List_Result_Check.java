package Test_Cases;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;





import Page_Objects_AutocompleteFeature.AutocompleteFeature;
import Page_Objects_AutocompleteFeature.SearchResults;

public class Suggestion_List_Result_Check  extends Baseclass{
	
	private static final boolean String = false;
	
	
	
	@Test
	public void suggetion_list_validation() throws IOException, InterruptedException {
	
	driver = initilizeDriver();
	driver.get(prop.getProperty("Home_URL"));

	//Object creation for Page_Objects_AutocompletionFeature
	AutocompleteFeature af = new AutocompleteFeature(driver);
	SearchResults sr = new SearchResults(driver);
	
	//Searching for a word in the Autocomplete Textbox. The "search_word" will be retrieved from in data.properties file
	af.search_textbox().sendKeys(prop.getProperty("Search_word"));
	
	
	List<WebElement> objlinks = af.suggestion_list();
			
	
	for (WebElement objlink : objlinks) {
		
		//Printing available suggestions to the console
	 System.out.println(objlink.getText());
		

		//Identifying the matching suggestion
	  if (objlink.getText().contains(prop.getProperty("Actual_word"))) {
         
	    objlink.click();
	    	
	   	 }
	
	}
	
	
	//WebDriverWait wait = new WebDriverWait(driver, 50);
	//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='s-result-count']/span/span")));
	
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
	// Validation of the Search Result page
	
	String searchresult = (sr.result_text().getText());
	
	if (searchresult.contains(prop.getProperty("Actual_word"))) {
		 System.out.println("The Search Results Verified");
	}
	
	
	driver.quit();
	}

}
	
	

