package Page_Objects_AutocompleteFeature;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AutocompleteFeature{
		
		WebDriver driver;
		
		public AutocompleteFeature(WebDriver driver){
			
			this.driver = driver;
				
		}
		
		
		By search_textbox = By.id("twotabsearchtextbox");
		By search_button = By.xpath(".//input[@value='Go']");
		By suggestion_list = By.xpath("//*[@id='suggestions']");
	
		
		public WebElement search_textbox() {
			
		
			return (driver.findElement(search_textbox));
		
		}
		
		public WebElement search_button() {
			
			
			return (driver.findElement(search_button));
		
		}
		
		
		public List<WebElement> suggestion_list() {
			
			
			return(driver.findElements(suggestion_list));
		}
		
	}
			
 	
	

	
	

