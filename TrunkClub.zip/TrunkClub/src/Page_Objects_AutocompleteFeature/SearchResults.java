package Page_Objects_AutocompleteFeature;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchResults {

	
	WebDriver driver;
	
	public SearchResults(WebDriver driver){
		
		this.driver = driver;
			
	}
	
	
	By result_text = By.xpath("//*[@id='s-result-count']/span/span");
	
	
	public WebElement result_text() {
		
		
		return (driver.findElement(result_text));
		
	}
	
	
	
	public String page_source() {
		
		
		return(driver.getPageSource());
	}
	
	
	
}
